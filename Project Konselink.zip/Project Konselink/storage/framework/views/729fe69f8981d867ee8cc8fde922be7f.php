<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon.ico')); ?>">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script type="text/javascript" src="<?php echo e(('jquery/jquery.min.js')); ?>"></script>
    <title>Konselink</title>
    <style>

        .login-page{
            background-image: url('./assets/bulet.png');
            background-position: top-left;
            background-repeat: no-repeat;
            background-size: 500px;
        }

        @media (max-width: 960px) {
            .form-login{
                display: none;
            }
        }

        .hrdivider {
        position: relative;
        margin-bottom: 50px;
        width: 100%;
        margin-top: 50px;

        }

        .hrdivider span {
        position: absolute;
        top: -11px;
        background: #fff;
        padding: 0 10px;
        font-weight: bold;
        font-size: 14px;

        }
    </style>
</head>
<body style="background-color: #F4F4F4; font-family: 'Poppins';">
<!-- Content -->
<div class="login-page">
<div class="container-fluid">
    <div class="row">
        <div class="col-8 form-login">
            <div class="container mt-5 pt-4" style="margin-left: 120px">
                <h1 class="text-white fw-bold" style="font-size: 90px; text-shadow: 1px 1px 3px rgba(0,0,0,0.6);">KONSEL<span style="color: #1E2772">INK<img src="/assets/toga.png" class="img-fluid mb-3" style="width: 60px;" alt="..."></span></h1>
            </div>
            <div class="row">
                <div class="col d-flex justify-content-center" style="padding-top: 0px;">
                    <img src="assets/bk.png" alt="..." style="width: 750px;" class="img-fluid">
                </div>
            </div>
        </div>
        <div class="col-xl-4" style="background-color: white; height: 100vh;">
            <div class="container">
            <div class="row mt-5">
                <div class="col-6 text-end">
                    <img class="img-fluid" src="assets/konselor.png" style="height: 120px; width: 120px;">
                </div>
                <div class="col-6 text-start">
                    <img class="img-fluid" src="assets/NESKAR.png" style="height: 120px; width: 120px;">
                </div>
            </div>
            <div class="container-fluid mt-5">
                <p class="text-center">Login  akun Guru BK</p>
                <form>
                  <label for="form-email" class="form-label">Email</label>
                  <div class="input-group mb-3">
                    <input type="text" style="background-color: #EEEEEE" class="form-control" placeholder="Masukkan email  Guru BK" id="form-email" aria-label="Username" aria-describedby="basic-addon1">
                    <span class="input-group-text" style="background-color: #1E2772" id="basic-addon1"><img src="assets/mail.png" alt=""></span>
                  </div>
                  <label for="form-password" class="form-label">Password</label>
                  <div class="input-group mb-3">
                    <input type="text" style="background-color: #EEEEEE" class="form-control" placeholder="Masukkan password untuk Guru BK" id="form-password" aria-label="Username" aria-describedby="basic-addon1">
                    <span class="input-group-text" style="background-color: #1E2772" id="basic-addon1"><img src="assets/lock.png" alt=""></span>
                  </div>
                  <div class="d-flex justify-content-end">
                    <a class="text-end" href="">Lupa Password?</a>
                  </div>
                  <div class="d-flex justify-content-center">
                      <button type="button" style="background-color: #1E2772;" class="btn w-100 mt-3 text-white">Masuk</button>
                  </div>
                  <div class="hrdivider text-secondary">
                    <hr/>
                    <span style="margin-left: 200px;">ATAU</span>
                  </div>
                  <button type="button" class="btn btn-outline-primary w-100">Daftar</button>
                </form>
            </div>
            </div>
        </div>
    </div>

</div>
</div>
<!-- Content END -->
<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\GitHub\Private\Project Konselink\resources\views/auth/login.blade.php ENDPATH**/ ?>